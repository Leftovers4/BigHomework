package util;

/**
 * Created by kevin on 2016/11/23.
 */
public class UserLevel {
    public static final int MAX_LEVEL = 6;
}
