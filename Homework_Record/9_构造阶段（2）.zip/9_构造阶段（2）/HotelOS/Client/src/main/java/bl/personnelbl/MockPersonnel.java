package bl.personnelbl;

/**
 * Created by kevin on 2016/11/6.
 */
public class MockPersonnel extends Personnel {

    /**
     * 工作人员ID
     */
    private long personnelID;

    /**
     * 密码
     */
    private String password;



}
