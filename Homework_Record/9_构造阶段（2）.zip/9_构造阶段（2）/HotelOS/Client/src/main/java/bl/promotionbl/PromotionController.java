package bl.promotionbl;

import blservice.promotionblservice.PromotionBLService;
import util.ResultMessage;
import vo.promotion.PromotionVO;

import java.util.ArrayList;

/**
 * Created by kevin on 2016/11/6.
 */
public class PromotionController implements PromotionBLService{

    @Override
    public ResultMessage create(PromotionVO promotionVO) {
        return null;
    }

    @Override
    public ResultMessage delete(long id) {
        return null;
    }

    @Override
    public ResultMessage update(long id) {
        return null;
    }

    @Override
    public ArrayList<PromotionVO> showList(long creator) {
        return null;
    }
}
