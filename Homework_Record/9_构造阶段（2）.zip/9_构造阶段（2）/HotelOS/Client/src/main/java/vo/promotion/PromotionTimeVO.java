package vo.promotion;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * Created by Hiki on 2016/10/27.
 */
public class PromotionTimeVO {

    /**
     * 开始时间
     */
    public LocalDateTime beginTime;

    /**
     * 结束时间
     */
    public LocalDateTime endTime;


    public PromotionTimeVO(LocalDateTime beginTime, LocalDateTime endTime) {
        this.beginTime = beginTime;
        this.endTime = endTime;
    }
}
