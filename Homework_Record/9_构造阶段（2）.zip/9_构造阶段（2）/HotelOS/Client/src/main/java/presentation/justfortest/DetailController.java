/**
 * Created by:Hitiger
 * Date: 2016/11/14   Time: 19:45
 * Description:
 */
public class DetailController {
}
