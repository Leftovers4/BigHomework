package util;

/**
 * Created by Hiki on 2016/10/16.
 */
public enum RoomType {

    /**
     * 单人房
     */
    SINGLE,

    /**
     * 双人房
     */
    COUPLE

}
