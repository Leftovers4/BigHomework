package util;

/**
 * Created by Hiki on 11/19/2016.
 */
public enum PersonnelType {

    /**
     * 酒店工作人员
     */
    HOTEL_WORKER,

    /**
     * 网站营销人员
     */
    WEB_MARKETER,

    /**
     * 网站管理人员
     */
    WEB_ADMINISTRATOR,
}
