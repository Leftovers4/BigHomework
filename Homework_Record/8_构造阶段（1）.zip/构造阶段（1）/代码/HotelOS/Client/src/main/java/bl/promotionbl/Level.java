package bl.promotionbl;

/**
 * Created by kevin on 2016/11/18.
 */
public interface Level extends Promotion {
    int getLevel(double credit);
}
