package bl.hotelbl;

import vo.hotel.RoomVO;

import java.util.ArrayList;

/**
 * Created by kevin on 2016/11/6.
 */
public class Hotel implements RoomInfoService{
    @Override
    public ArrayList<RoomVO> getRooms() {
        return null;
    }

    @Override
    public ArrayList<RoomVO> setRooms() {
        return null;
    }
}
