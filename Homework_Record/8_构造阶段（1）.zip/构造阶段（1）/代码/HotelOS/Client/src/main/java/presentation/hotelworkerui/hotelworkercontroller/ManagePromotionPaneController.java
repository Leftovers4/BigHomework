package presentation.hotelworkerui.hotelworkercontroller;

import javafx.stage.Stage;

/**
 * Created by Hitiger on 2016/11/20.
 * Description :
 */
public class ManagePromotionPaneController {
    private Stage stage;

    public void launch(Stage primaryStage) {
        this.stage = primaryStage;
    }
}
