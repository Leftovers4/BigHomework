package bl.promotionbl;

import vo.order.OrderVO;

/**
 * Created by kevin on 2016/11/6.
 */
public interface Promotion {
}
