package bl.orderbl;

import bl.hotelbl.RoomInfoService;

/**
 * Created by kevin on 2016/11/6.
 */
public class Order {
    RoomInfoService roomInfoService;
}
