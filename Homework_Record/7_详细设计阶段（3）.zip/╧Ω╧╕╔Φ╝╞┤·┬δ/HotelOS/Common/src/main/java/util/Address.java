package util;

/**
 * Created by Hiki on 2016/10/16.
 */
public enum Address {

    /**
     * 南京
     */
    NANJING
}
