package bl.userbl;

/**
 * Created by kevin on 2016/11/6.
 */
public class Member {
}
