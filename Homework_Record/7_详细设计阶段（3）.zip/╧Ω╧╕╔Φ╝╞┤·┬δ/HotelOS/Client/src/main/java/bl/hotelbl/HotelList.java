package bl.hotelbl;

/**
 * Created by kevin on 2016/11/6.
 */
public class HotelList {
}
