package bl.promotionbl;

/**
 * Created by kevin on 2016/11/6.
 */
public class EnterpriseHP {
}
