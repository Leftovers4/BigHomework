package util;

/**
 * Created by Hiki on 2016/10/16.
 */
public enum PromotionType {

    /**
     * 酒店营销策略
     */
    HOTEL_PROMOTION,

    /**
     * 网站营销策略
     */
    WEB_PROMOTION,

}
