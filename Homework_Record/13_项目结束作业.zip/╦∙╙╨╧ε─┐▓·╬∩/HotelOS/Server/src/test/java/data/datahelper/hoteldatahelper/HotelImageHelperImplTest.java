package data.datahelper.hoteldatahelper;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Hiki on 12/5/2016.
 */
public class HotelImageHelperImplTest {

    HotelImageHelperImpl tested;

    @Before
    public void setUp() throws Exception {
        tested = new HotelImageHelperImpl();
    }

    @Test
    public void findHotelImageByHotelID() throws Exception {
        // TODO
    }

    @Test
    public void setHotelImage() throws Exception {
        // TODO
    }

}