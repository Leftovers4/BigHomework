package util;

/**
 * Created by Hiki on 2016/10/16.
 */
public enum TradingArea {

    /**
     * 仙林中心
     */
    XIANLIN_CENTER,

}
