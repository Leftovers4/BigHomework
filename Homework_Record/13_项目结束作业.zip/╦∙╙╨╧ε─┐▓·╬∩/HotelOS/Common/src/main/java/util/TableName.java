package util;

/**
 * Created by Hiki on 11/21/2016.
 */
public enum TableName {

    address,
    credit_record,
    hotel,
    order_info,
    personnel,
    promotion,
    room,
    user,

}
