package bl.promotionbl.impl;

import po.promotion.PromotionPO;

/**
 * Created by kevin on 2016/11/6.
 */
public interface Promotion {
}
