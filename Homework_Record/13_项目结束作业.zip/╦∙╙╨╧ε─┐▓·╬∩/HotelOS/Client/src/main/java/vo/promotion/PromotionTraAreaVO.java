package vo.promotion;

/**
 * Created by kevin on 2016/12/5.
 */
public class PromotionTraAreaVO {

    public String tradingArea;

    public double traDiscount;

    public PromotionTraAreaVO(){
        tradingArea = "";
        traDiscount = 1;
    }

}
