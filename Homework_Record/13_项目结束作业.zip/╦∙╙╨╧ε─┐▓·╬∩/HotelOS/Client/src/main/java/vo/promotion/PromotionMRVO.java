package vo.promotion;

/**
 * Created by kevin on 2016/12/5.
 */
public class PromotionMRVO {

    /**
     * 信用值
     */
    public double credit;

    /**
     * 折扣
     */
    public double memberDiscount;

}
